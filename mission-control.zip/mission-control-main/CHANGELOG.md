# Changelog

All notable changes to Mission Control will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.2.1] - 2026-01-31

### Security

- **Input sanitization in `mc-update.sh`** — Rejects arguments containing backticks or `$` to prevent shell/string injection
- **Credential scanning** — Pre-sync checks before open-source publishing
- **No tokens or secrets** stored in the dashboard

---

## [2.2.0] - 2026-01-30

### Added

- **Version Update Banner** — Dashboard now shows a notification banner when a new version is available
  - Checks `data/version.json` every 5 minutes
  - Also checks when tab becomes visible again
  - Stylish gradient banner with refresh button
  - Dismissable (stops checking for current session)
- **`scripts/update-version.sh`** — Helper script to update version.json with current git hash
- **`data/version.json`** — Version tracking file with buildHash and buildTime

### Technical

- CSS styles for `.version-banner` with pulse animation
- `checkForUpdates()`, `showVersionBanner()`, `dismissVersionBanner()` JavaScript functions
- Cache-busting on version check requests
- Version check also triggers on `visibilitychange` event

---

## [2.1.0] - 2026-01-30

### Added

- **Recurring Column** — New "Recurring" column (leftmost) displays automated cronjobs from Clawdbot Gateway
- **Cron Cards** — Visual representation of cronjobs with:
  - Status indicator (🟢 active / ⚪ disabled / 🔴 error)
  - Human-readable schedule ("Täglich um 08:00", "Montags 08:00")
  - Last run and next run timestamps (relative time)
- **`data/crons.json`** — JSON data source for recurring jobs
- **`scripts/sync-to-opensource.sh`** — Exports sanitized crons for open source distribution
- **Processing Timer** — Shows elapsed time on processing tasks with 30-minute timeout warning
- **Processing Border Pulse** — Visual pulsing effect on cards being processed

### Technical

- CSS styles for `.cron-card`, `.cron-status`, `.recurring-column`
- `loadCrons()` and `renderCrons()` JavaScript functions
- `formatCronExpression()` converts cron syntax to German-readable text
- Enhanced `renderTaskCard()` with time display and timeout detection

---

## [2.0.0] - 2026-01-30

### ⚠️ Breaking Changes

- **Config Location Changed** — Config now lives in `~/.clawdbot/mission-control.json` instead of being hardcoded
- **Transform Module Renamed** — Now uses `github-mission-control.mjs` (copy to `~/.clawdbot/hooks-transforms/`)
- **Setup Script Removed** — `scripts/mc-setup.sh` is deprecated; use agent-guided setup instead

### Added

- **Dynamic Configuration** — All settings loaded from `~/.clawdbot/mission-control.json`
- **Environment Variable Fallbacks** — Override config via `CLAWDBOT_GATEWAY`, `MC_WORKSPACE`, etc.
- **Agent-Guided Setup** — Say "Set up Mission Control" and the agent handles everything
- **EPIC Support** — Parent tasks can contain child tickets for sequential execution
- **Extended Timeouts for EPICs** — Automatically calculated based on number of children
- **Repo Info from Payload** — No more hardcoded GitHub URLs; extracted from webhook
- **New Documentation**:
  - `docs/PREREQUISITES.md` — Installation requirements
  - `docs/HOW-IT-WORKS.md` — Technical architecture
  - `docs/TROUBLESHOOTING.md` — 10 common issues with solutions
- **Example Configurations**:
  - `assets/examples/mission-control.json`
  - `assets/examples/CONFIG-REFERENCE.md`
  - `assets/examples/clawdbot-hooks-config.json`
  - `assets/examples/HOOKS-CONFIG.md`

### Changed

- **SKILL.md Rewritten** — Focus on agent-guided setup, removed manual steps
- **README.md Simplified** — Quick start section, badges, links to docs
- **Transform Location** — Moved to `assets/transforms/` for distribution

### Removed

- `scripts/mc-setup.sh` — Replaced by agent-guided setup
- Hardcoded paths, tokens, and URLs in transform module
- Manual webhook setup instructions (agent handles this now)

### Fixed

- GitHub API caching issues resolved via Git Blob API
- Snapshot desync on concurrent updates
- HMAC timing attacks prevented with `timingSafeEqual`

## [1.0.0] - 2026-01-28

Initial release.

### Added

- Kanban dashboard (single-page HTML app)
- GitHub Pages deployment
- `mc-update.sh` CLI tool
- Webhook integration with Clawdbot
- Diff-based change detection
- Auto-processing for "In Progress" tasks
- Subtask management
- Comment system
- Activity feed
- Search functionality
- Archive feature for completed tasks
